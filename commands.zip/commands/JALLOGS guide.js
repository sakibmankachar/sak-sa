module.exports = {
  name: "JALLOGS guide",
  code: `$title[GUIDE FOR HTMWALLWBDFD]
$description[Wanna to learn how to make welcome and leave logs with BDFD?
Download this file and learn
Download link [Click Here](https://www.dropbox.com/s/88l9rgm9e0bxz39/Guide%20for%20HTMWALLWBDFD.doc?dl=0) or [Click Here](https://cdn.discordapp.com/attachments/798154805699805234/800273753682214932/Guide_for_HTMWALLWBDFD.doc)
Note: Remember to learn the Main Guide. For Main Guide type s.guide]`
}