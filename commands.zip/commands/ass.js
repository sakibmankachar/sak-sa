module.exports = {
  name: "ass",
  code: `$onlyIf[$getServerVar[voteaccess]==False;
❌You have to vote Me to access This Command.
After Voting type s.voteaccess]
$color[ff0000]
$onlyNSFW[❌This command can only be used in the NSFW channel]
$description[**Here Some Ass From Me**]
$image[$randomText[https://cdn.boob.bot/ass/4FBF.JPG;https://cdn.boob.bot/ass/4CE0.JPG;https://cdn.boob.bot/ass/4ECF.JPG;https://cdn.boob.bot/ass/4C83.JPG;https://cdn.boob.bot/ass/4E48.JPG;https://cdn.boob.bot/ass/4CB0.JPG;https://cdn.boob.bot/ass/4EC0.JPG;https://cdn.boob.bot/ass/50BE.JPG;https://cdn.boob.bot/ass/4CE0.JPG;https://cdn.boob.bot/ass/50A0.JPG;https://cdn.boob.bot/ass/4C95.JPG;https://cdn.boob.bot/ass/4D94.JPG;https://cdn.boob.bot/ass/50A0.JPG;https://cdn.boob.bot/ass/4E1B.JPG;https://cdn.boob.bot/ass/4DFD.JPG;https://cdn.boob.bot/ass/4D67.JPG;https://cdn.boob.bot/ass/4EDE.JPG;https://cdn.boob.bot/ass/4C95.JPG;https://cdn.boob.bot/ass/4FDD.JPG;https://cdn.boob.bot/ass/4FB0.JPG;https://cdn.boob.bot/ass/5073.JPG;https://cdn.boob.bot/ass/4C74.JPG;https://cdn.boob.bot/ass/4CE0.JPG;https://cdn.boob.bot/ass/4ECF.JPG;https://cdn.boob.bot/ass/4DDF.JPG;https://cdn.boob.bot/ass/4DA3.JPG;https://cdn.boob.bot/ass/4DB2.GIF;https://cdn.boob.bot/ass/4C83.JPG;https://cdn.boob.bot/ass/4C95.JPG;https://cdn.boob.bot/ass/4D3A.JPG;https://cdn.boob.bot/ass/4C95.JPG;https://cdn.boob.bot/ass/4EFC.JPG;https://cdn.boob.bot/ass/4FFB.JPG;https://cdn.boob.bot/ass/4DC1.JPG;https://cdn.boob.bot/ass/4E48.JPG;https://cdn.boob.bot/ass/50FA.JPG;https://cdn.boob.bot/ass/5028.JPG;https://cdn.boob.bot/ass/50A0.JPG;https://cdn.boob.bot/ass/5136.JPG;https://cdn.boob.bot/ass/4EFC.JPG;https://cdn.boob.bot/ass/50DC.JPG;https://cdn.boob.bot/ass/4FA1.JPG;https://cdn.boob.bot/ass/500A.JPG;https://cdn.boob.bot/ass/4C68.JPG;https://cdn.boob.bot/ass/5064.JPG;https://cdn.boob.bot/ass/4C92.JPG;https://cdn.boob.bot/ass/4F0B.JPG;https://cdn.boob.bot/ass/4EC0.JPG;https://cdn.boob.bot/ass/5037.JPG;https://cdn.boob.bot/ass/4C77.JPG;https://cdn.boob.bot/ass/5091.JPG]]
$footer[Requested by $username#$discriminator[$authorID]]
$color[0adcc5]
$cooldown[3s;Please Wait %time%.]`
}