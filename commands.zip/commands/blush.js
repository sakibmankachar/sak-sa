module.exports = {
  name: "blush",
  code: `$description[$randomText[**$username is blushing cute**;**$username's face is Red as Tomato**]]
$image[$randomText[https://i.gifer.com/7Ago.gif;https://i.gifer.com/Pkog.gif;https://i.gifer.com/8xtr.gif;https://i.gifer.com/J6EH.gif;https://i.gifer.com/FKtx.gif;https://i.gifer.com/Azxk.gif;https://i.gifer.com/ADu5.gif;https://i.gifer.com/3Jdq.gif]]`
}