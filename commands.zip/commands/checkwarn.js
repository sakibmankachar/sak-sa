module.exports = {
  name: "checkwarn",
  code: `$color[#FF0000]

$title[Warn Check]

$description[<@$mentioned[1]> user has $getUserVar[warns;$mentioned[1]] warns]`
}