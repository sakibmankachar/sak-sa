module.exports = {
  name: "guide",
  code: `$title[GUIDE]
$description[Wanna to learn how to create and code a discord bot on Android with Bot designer for discord?
Then download this file and learn
Download link [Click Here](https://www.dropbox.com/s/caniq99sxmen9rr/Guide%20For%20HTCACADBOAWBDFD.doc?dl=0) or [Click Here](https://cdn.discordapp.com/attachments/798154805699805234/800274401320894474/Guide_For_HTCACADBOAWBDFD.doc)]
$color[#ff2052]
$footer[THANKS FOR READING!]`
}