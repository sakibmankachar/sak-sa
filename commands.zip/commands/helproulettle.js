module.exports = {
  name: "helproulettle",
  code: `$title[HELP IN ROULETTE!]
$description[In this game the player bet on the particular money the player has to choose the colour red or black there is also a spin if the arrow stopes in your selected color that means you win. The beginner start with $500 and slowly increase there money.]
$footer[I HOPE THAT YOU UNDERSTAND!]
$color[#ff2052]
$botTyping`
}