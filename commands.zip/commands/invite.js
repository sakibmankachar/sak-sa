module.exports = {
  name: "invite",

  code: `$title[INVITE]

$description[Want To Invite Me In Your Server?

Here's my invite link 
https://discord.com/oauth2/authorize?client_id=804720808182022245&scope=bot&permissions=2080898175

If you want Support Then Join My Official Support Server

Here my Official Support Server Join Link 
https://discord.gg/96BqdnWvh8 ]

$footer[Sak-bot]`
}