module.exports = {
  name: "kiss",
  code: `$color[#ff2053]
$title[Kiss]
$description[**$username** Kiss **<@$mentioned[<]>**]
$image[$randomText[https://cdn.discordapp.com/attachments/572486432384352268/633970015900794880/5bca76823067b273a1108261103bf740tenor.gif;https://cdn.discordapp.com/attachments/572486432384352268/633970037694398484/6d75a30fab19a9751aae652dd211dd1cgiphy.gif;https://cdn.discordapp.com/attachments/572486432384352268/633970030513750017/80f94c90afd9f524c1b2e3cca20f1a45tenor_1.gif;https://cdn.discordapp.com/attachments/572486432384352268/633970023962247178/631c72f1880142f58089bdc695a27da4giphy_1.gif;https://cdn.discordapp.com/attachments/572486432384352268/633970030513750017/80f94c90afd9f524c1b2e3cca20f1a45tenor_1.gif;https://tenor.com/view/anime-kiss-love-sweet-gif-5095865;https://tenor.com/view/kiss-me-%D0%BB%D1%8E%D0%B1%D0%BB%D1%8E-anime-kiss-intimate-gif-17382422;https://tenor.com/view/anime-forehead-kiss-gif-12392648;https://tenor.com/view/kiss-anime-cute-kawaii-gif-13843260;https://tenor.com/view/love-cheek-peck-kiss-anime-gif-17382412;https://tenor.com/view/anime-kiss-gif-4829336;https://tenor.com/view/cute-kawai-kiss-anime-gif-16371489]]
$footerIcon[$authorAvatar]
$footer[Request by $username]`
}