module.exports = {
  name: "leaderboard",
  code: `$title[Balance Leaderboard]
  $description[$userLeaderboard[money;desc]]
$color[ff00ff]
`
}