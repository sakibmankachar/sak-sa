module.exports = {
  name: "meme",
  code: `$deletecommand
$image[$randomText[https://i.imgflip.com/31gy6j.jpg;http://memeville.weebly.com/uploads/1/7/5/6/17560407/6884621_orig.jpg;http://memeville.weebly.com/uploads/1/7/5/6/17560407/1710179.jpg;http://creativeedtech.weebly.com/uploads/4/1/6/3/41634549/summer_orig.png;http://creativeedtech.weebly.com/uploads/4/1/6/3/41634549/summer_orig.png;http://myriamsmemeoftheday.weebly.com/uploads/7/7/8/8/77889656/img-0166_orig.gif;http://myriamsmemeoftheday.weebly.com/uploads/7/7/8/8/77889656/img-0171_1.gif;https://imgflip.com/i/31k7kk;https://cdn.weeb.sh/images/B1VVWuaFf.jpeg;https://images.app.goo.gl/njyqD6L2dJ1m3qX19;https://images.app.goo.gl/WLLbBKmbWZwsFLqh7;]]`
}
