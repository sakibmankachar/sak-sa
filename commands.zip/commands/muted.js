module.exports = {
  name: "muted",
  code: `$mute[muted]

$title[MUTE]

$description[<@$mentioned[<]> Is muted by $username] 

$footer[Muted by $username]

$argsCheck[>1;Please mention someone]

$onlyPerms[manageroles;You cannot use this command]`
}
