module.exports = {
  name: "pussy",
  code: `$onlyIf[$getServerVar[voteaccess]==False;
❌You have to vote Me to access This Command.
After Voting type s.voteaccess]
$onlyNSFW[❌This command can only be used in the NSFW channel]
$description[**Here Some Pussy From Me**]
$image[$randomText[https://171gifs.com/wp-content/uploads/2017/06/Gif-Lesbian-pussy-licking-with-hip-rolling.gif;https://171gifs.com/wp-content/uploads/2013/10/Johnny-Castle-licks-Dana-Vespolis-hairy-pussy.gif;https://171gifs.com/wp-content/uploads/2013/08/Tyler-Nixon-licking-Mikki7-Lynn-pink-pussy.gif;https://171gifs.com/wp-content/uploads/2017/06/Gif-Pussy-Licking-Cunnilingus-Oral-Sex-Gif.gif;https://171gifs.com/wp-content/uploads/2017/06/Gif-Hot-Facesitting-and-Pussy-Licking-GIF.gif;https://171gifs.com/wp-content/uploads/2013/09/Dani-Daniels-licking-Remy-LaCroix-pussy.gif;https://171gifs.com/wp-content/uploads/2017/06/Gif-Repin-and-follow-for-more-pussy-licking-lesbian-gifs.gif;https://171gifs.com/wp-content/uploads/2017/06/Gif-Pussy-Licking-Porn-GIFs.gif;https://171gifs.com/wp-content/uploads/2017/02/Peta-Jensen-Flixxx-Please-Come-Fuck-Me-05-pussy-licking.gif;https://171gifs.com/wp-content/uploads/2017/06/Gif-Pussy-licking-gif-eating-lips.gif;https://171gifs.com/wp-content/uploads/2017/02/Dillion-Harper-licking-shaved-pussy-on-the-shower.gif;https://171gifs.com/wp-content/uploads/2017/06/Gif-Pussy-licking-gif-pink-vagina.gif;https://171gifs.com/wp-content/uploads/2017/06/Gif-The-Best-Pussy-Licking-Porn-GIFs.gif;https://171gifs.com/wp-content/uploads/2017/06/Gif-Cunnilingus-Eating-Pussy-Licking-MILF-Lingerie-GIF.gif;https://171gifs.com/wp-content/uploads/2017/06/Gif-Pussy-Licking-Female-POV-loseup-Porn-Gif.gif;https://171gifs.com/wp-content/uploads/2013/10/Aaliyah-Love-fucked-licking-Cherie-Deville-pussy.gif;https://171gifs.com/wp-content/uploads/2017/06/Gif-Busty-Pussy-Licking-krissy-lynn.gif;https://171gifs.com/wp-content/uploads/2017/06/Gif-Facesitting-Cunnilingus-Pussy-Licking-Porn-Gif.gif]]
$color[#fffff]
$cooldown[3s; Please Wait %time%]
$footer[Requested by $username#$discriminator[$authorID]]`
}