module.exports = {
  name: "resetprefix",
  code: `$title[Reset Prefix]
$description[Successfully reseted and restored the default prefix]
$setServerVar[prefix;s.]
$onlyPerms[admin;manageserver;You can't use this command]
`
}