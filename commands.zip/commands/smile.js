module.exports = {
  name: "smile",
  code: `$color[$random[0;99999]]
$description[$randomText[<@$authorID> puts a big smile!;$username smile;$username smile like a $randomText[angel;devil]]]
$image[$randomText[https://media.tenor.com/images/d62e090630ff6829fda329b86ea723e0/tenor.gif;https://media.tenor.com/images/f4273baaa0b2493f1c4b2d4ed32aaa9c/tenor.gif;https://media.tenor.com/images/4ea5a1f32764091f5c433bf0b1c778d1/tenor.gif;https://media.tenor.com/images/7cb5e535bcade89f2979cd3dd3bfde5a/tenor.gif;https://media.tenor.com/images/1a30a0af6eeed4c9a0e33a233158d885/tenor.gif]]`
}