module.exports = {
  name: "unban",
  code: `$unban

$onlyAdmin[You need a higher role to execute that.]

$description[User has been unbanned.]

$deleteIn[5s]

$deletecommand`
}