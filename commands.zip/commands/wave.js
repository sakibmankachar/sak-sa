module.exports = {
  name: "wave",
  code: `$title[**$username Makes a wave**]
$image[$randomText[https://cdn.discordapp.com/attachments/811553917191716877/811941952929005600/tenor_8.gif;https://cdn.discordapp.com/attachments/811553917191716877/811941953477541888/tenor_7.gifhttps://cdn.discordapp.com/attachments/811553917191716877/811941954119139338/tenor_6.gif;https://cdn.discordapp.com/attachments/811553917191716877/811941954556264458/tenor_5.gif;https://cdn.discordapp.com/attachments/811553917191716877/811941954845540372/tenor_4.gif;https://cdn.discordapp.com/attachments/811553917191716877/811941955361308682/tenor_3.gif;https://cdn.discordapp.com/attachments/811553917191716877/811941956245651546/tenor_2.gif;https://cdn.discordapp.com/attachments/811553917191716877/811941956678582343/tenor_1.gif;https://cdn.discordapp.com/attachments/811553917191716877/811941957025923072/tenor.gif]]
$addTimestamp
$color[$random[0;99999]]`
}